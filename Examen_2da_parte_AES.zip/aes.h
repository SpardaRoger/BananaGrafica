
typedef unsigned char B8;
typedef unsigned short int B16;
typedef unsigned long int B32;


#define Nb 4
#define debug 1 

B16 Nk;
B16 Nr;
